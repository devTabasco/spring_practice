package icia.js.changyong.services.goods;

public interface GoodsManagement {

	public void backController();
	public void getGoodsListCtl();
	public void insGoodsCtl();	
	public void getCategoryListCtl();	
	public void insCategoryCtl();
	public void updCategoryCtl();
	public boolean convertToBoolean();

}
